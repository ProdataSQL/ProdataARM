Script ChangeCDROMDriveLetter 
{
    GetScript = {
        @{
            GetScript = $GetScript
            SetScript = $SetScript
            TestScript = $TestScript
            Result = (Get-CimInstance -ClassName Win32_Volume -Filter "DriveLetter = 'D:'").DriveType -ne 5
        }           
    }
            
    SetScript = {
        Get-CimInstance -ClassName Win32_Volume -Filter "DriveLetter = 'D:'" | Set-CimInstance -Property @{ DriveLetter = "Z:" }
    }

    TestScript = {
        $Status = (Get-CimInstance -ClassName Win32_Volume -Filter "DriveLetter = 'D:'").DriveType -ne 5
        $Status -eq $True
    }
}